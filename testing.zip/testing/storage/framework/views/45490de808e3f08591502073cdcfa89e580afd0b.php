 <!-- Main Content -->
 <div class="main-content">
        <section class="section">
          <div class="section-body">
          <section class="section">
          <div class="section-header">
            <h1>Testing Crud</h1>
            <div class="section-header-breadcrumb">
              <div class="breadcrumb-item active"><a href="#">Dashboard</a></div>
              <div class="breadcrumb-item"><a href="#">Components</a></div>
              <div class="breadcrumb-item">Table</div>
            </div>
          </div>

          <div class="section-body">
            <div class="row">
              <div class="col-12 col-md-6 col-lg-6">
                <div class="card">
                  <div class="card-header">
                    <h4>Testig Table</h4>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-bordered table-md">
                        <tr>
                          <th>NO</th>
                          <th>TITLE</th>
                          <th>CATEGORY</th>
                          <th>CONTENT</th>
                          <th>ACTION</th>
                        </tr>
                        <?php $i=1 ?>
                          <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          
                          <td><?php echo e($i++); ?></td>
                          <td><?php echo e($blog->Title); ?></td>
                          <td><?php echo e($blog->Category); ?></td>
                          <td><?php echo e($blog->Content); ?></td>
                          <td>
                          <form action="" method="POST">   
                              <a class="btn btn-info" href="">Show</a>    
                              <a class="btn btn-primary" href="">Edit</a>   
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('DELETE'); ?>      
                              <button type="submit" class="btn btn-danger">Delete</button>
                          </form>
                          </td>
                          
                        </tr> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </table>
                    </div>
                </div>
          </div>
        </section>
        </section>
      </div><?php /**PATH C:\xampp\htdocs\testing\resources\views/layouts/partials/maincontent.blade.php ENDPATH**/ ?>