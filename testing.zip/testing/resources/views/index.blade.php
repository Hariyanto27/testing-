<!DOCTYPE html>
<html lang="en">
    <head>
    @include('layouts.partials.head')
    </head>
    <body>
        <div id="app">
            <div class="main-wrapper">
            <div class="navbar-bg"></div>
            @include('layouts.partials.header')
            @include('layouts.partials.sidebar')
            @include('layouts.partials.maincontent')
</div>
@include('layouts.partials.js')
</body>