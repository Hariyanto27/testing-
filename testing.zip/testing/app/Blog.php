<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Blog extends Model
{
    protected $table = 'Blogs';
    protected $fillable = [
        'Title',
        'Category',
        'Content'
    ];

    protected $primaryKey = 'ID';
}
